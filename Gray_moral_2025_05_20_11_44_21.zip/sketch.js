let modo = 'campo'; // 'campo' ou 'cidade'
let solLuaY;
let nuvemX;
let passaroX = [];
let passaroY = [];
let passaroVelocidade = [];
let numPassaros = 5;

function setup() {
  createCanvas(800, 500);
  solLuaY = height / 4;
  nuvemX = width / 2;

  for (let i = 0; i < numPassaros; i++) {
    passaroX[i] = random(width);
    passaroY[i] = random(50, 150);
    passaroVelocidade[i] = random(1, 3);
  }
}

function draw() {
  if (modo === 'campo') {
    desenhaCampo();
  } else {
    desenhaCidade();
  }

  // Elementos que aparecem em ambos os modos
  desenhaSolLua();
  desenhaNuvem();
  desenhaPassaros();
  desenhaPlacaModo(); // Uma plaquinha para indicar o modo
}

function desenhaCampo() {
  // Céu do campo (azul claro)
  background(135, 206, 235);

  // Grama (verde)
  fill(124, 252, 0);
  noStroke();
  rect(0, height * 0.6, width, height * 0.4);

  // Flores (círculos coloridos aleatórios)
  for (let i = 0; i < 30; i++) {
    let x = random(width);
    let y = random(height * 0.65, height * 0.95);
    let tamanho = random(5, 15);
    fill(random(150, 255), random(150, 255), random(150, 255), 200); // Cores pastel
    ellipse(x, y, tamanho);
  }

  // Árvores (tronco marrom e copa verde)
  fill(139, 69, 19); // Marrom
  rect(width * 0.2, height * 0.4, 30, height * 0.3);
  rect(width * 0.7, height * 0.45, 30, height * 0.25);
  fill(34, 139, 34); // Verde floresta
  ellipse(width * 0.2 + 15, height * 0.4, 80, 100);
  ellipse(width * 0.7 + 15, height * 0.45, 70, 90);
}

function desenhaCidade() {
  // Céu da cidade (tons de cinza/azul escuro para noite ou poluição)
  background(100, 149, 237); // Azul mais escuro

  // Ruas (cinza escuro)
  fill(50);
  noStroke();
  rect(0, height * 0.7, width, height * 0.3);

  // Prédios (retângulos de cores variadas)
  for (let i = 0; i < 8; i++) {
    let predioLargura = random(50, 100);
    let predioAltura = random(100, 300);
    let predioX = i * (width / 8) + random(-20, 20); // Espaçamento e leve variação
    let predioY = height * 0.7 - predioAltura;
    fill(random(80, 180), random(80, 180), random(80, 180)); // Tons de cinza/azul/marrom para prédios
    rect(predioX, predioY, predioLargura, predioAltura);

    // Janelas (quadradinhos amarelos)
    fill(255, 255, 0, 200); // Amarelo com transparência
    let numJanelasX = floor(predioLargura / 20);
    let numJanelasY = floor(predioAltura / 30);
    for (let j = 0; j < numJanelasX; j++) {
      for (let k = 0; k < numJanelasY; k++) {
        rect(predioX + 5 + j * 20, predioY + 5 + k * 30, 10, 10);
      }
    }
  }

  // Carros (retângulos pequenos coloridos)
  fill(random(255), random(255), random(255)); // Cores vibrantes
  rect(mouseX, height * 0.75, 40, 20); // Um carro segue o mouse na cidade
}

function desenhaSolLua() {
  noStroke();
  if (modo === 'campo') {
    // Sol amarelo
    fill(255, 255, 0);
    ellipse(width * 0.8, solLuaY, 80, 80);
  } else {
    // Lua branca/azulada
    fill(200, 200, 255);
    ellipse(width * 0.8, solLuaY, 70, 70);
  }
}

function desenhaNuvem() {
  fill(255, 255, 255, 200); // Nuvem branca com transparência
  noStroke();
  ellipse(nuvemX, 80, 100, 60);
  ellipse(nuvemX - 30, 70, 70, 50);
  ellipse(nuvemX + 40, 90, 80, 50);

  nuvemX += 0.5; // Movimento da nuvem
  if (nuvemX > width + 50) {
    nuvemX = -50;
  }
}

function desenhaPassaros() {
  fill(0); // Pássaros pretos
  for (let i = 0; i < numPassaros; i++) {
    // Desenha o formato de 'V' dos pássaros
    triangle(passaroX[i], passaroY[i],
             passaroX[i] + 10, passaroY[i] - 10,
             passaroX[i] + 20, passaroY[i]);

    passaroX[i] += passaroVelocidade[i];
    if (passaroX[i] > width + 20) {
      passaroX[i] = -20;
      passaroY[i] = random(50, 150);
      passaroVelocidade[i] = random(1, 3);
    }
  }
}

function desenhaPlacaModo() {
  fill(255, 100, 100); // Cor da plaquinha
  rect(10, 10, 150, 40, 10); // Retângulo arredondado
  fill(255); // Cor do texto
  textSize(18);
  textAlign(CENTER, CENTER);
  textStyle(BOLD);
  if (modo === 'campo') {
    text("Modo: CAMPO", 85, 30);
  } else {
    text("Modo: CIDADE", 85, 30);
  }
}

function mousePressed() {
  // Alterna entre campo e cidade ao clicar na tela
  if (modo === 'campo') {
    modo = 'cidade';
  } else {
    modo = 'campo';
  }
}